package com.amrita.jpl._21cys62.endsem;


/**
 * @author Ruthwik Krishna
 */

import java.io.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

abstract class File {
    private String fileName;
    private long fileSize;

    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public abstract void displayFileDetails();
}

class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void displayFileDetails() {
        System.out.println("Document: " + getFileName());
        System.out.println("Size: " + getFileSize() + " bytes");
        System.out.println("Type: " + getDocumentType());
    }
}

class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void displayFileDetails() {
        System.out.println("Image: " + getFileName());
        System.out.println("Size: " + getFileSize() + " bytes");
        System.out.println("Resolution: " + getResolution());
    }
}

class Video extends File {
    private String duration;

    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public void displayFileDetails() {
        System.out.println("Video: " + getFileName());
        System.out.println("Size: " + getFileSize() + " bytes");
        System.out.println("Duration: " + getDuration());
    }
}

interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void displayAllFiles();

    void saveToFile();

    void loadFromFile();

    ArrayList<File> getFiles();
}

class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        File fileToRemove = null;
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                fileToRemove = file;
                break;
            }
        }
        if (fileToRemove != null) {
            files.remove(fileToRemove);
            System.out.println("File \"" + fileName + "\" deleted.");
        } else {
            System.out.println("File \"" + fileName + "\" not found.");
        }
    }

    public void displayAllFiles() {
        if (files.isEmpty()) {
            System.out.println("No files found.");
        } else {
            System.out.println("Files:");
            for (File file : files) {
                file.displayFileDetails();
                System.out.println("-------------------------");
            }
        }
    }

    public void saveToFile() {
        try {
            FileWriter writer = new FileWriter("files.txt");
            for (File file : files) {
                if (file instanceof Document) {
                    Document document = (Document) file;
                    writer.write("Document Name: " + document.getFileName() + "\n");
                    writer.write("Size: " + document.getFileSize() + " bytes\n");
                    writer.write("Type: " + document.getDocumentType() + "\n");
                } else if (file instanceof Image) {
                    Image image = (Image) file;
                    writer.write("Image Name: " + image.getFileName() + "\n");
                    writer.write("Size: " + image.getFileSize() + " bytes\n");
                    writer.write("Resolution: " + image.getResolution() + "\n");
                } else if (file instanceof Video) {
                    Video video = (Video) file;
                    writer.write("Video Name: " + video.getFileName() + "\n");
                    writer.write("Size: " + video.getFileSize() + " bytes\n");
                    writer.write("Duration: " + video.getDuration() + "\n");
                }
                writer.write("-------------------------\n");
            }
            writer.close();
            System.out.println("File details saved to files.txt");
        } catch (IOException e) {
            System.out.println("Error saving file details: " + e.getMessage());
        }
    }

    public void loadFromFile() {
        files.clear();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("files.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Document Name: ")) {
                    String fileName = line.substring(16);
                    long fileSize = Long.parseLong(reader.readLine().substring(6));
                    String documentType = reader.readLine().substring(6);
                    Document document = new Document(fileName, fileSize, documentType);
                    files.add(document);
                } else if (line.startsWith("Image Name: ")) {
                    String fileName = line.substring(13);
                    long fileSize = Long.parseLong(reader.readLine().substring(6));
                    String resolution = reader.readLine().substring(12);
                    Image image = new Image(fileName, fileSize, resolution);
                    files.add(image);
                } else if (line.startsWith("Video Name: ")) {
                    String fileName = line.substring(13);
                    long fileSize = Long.parseLong(reader.readLine().substring(6));
                    String duration = reader.readLine().substring(10);
                    Video video = new Video(fileName, fileSize, duration);
                    files.add(video);
                }
                reader.readLine(); // Skip the line divider
            }
            reader.close();
            System.out.println("File details loaded from files.txt");
        } catch (IOException e) {
            System.out.println("Error loading file details: " + e.getMessage());
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}


class FileManagementSystemUI {
    private JFrame frame;
    private JTextField nameField;
    private JTextField sizeField;
    private JTextField typeField;
    private JTextField resolutionField;
    private JTextField durationField;
    private JTable table;
    private DefaultTableModel tableModel;
    private FileManager fileManager;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        initializeUI();
    }

    private void initializeUI() {
        frame = new JFrame("File Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 5, 5, 5);

        // File details components
        JLabel nameLabel = new JLabel("Name:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.EAST;
        panel.add(nameLabel, constraints);

        JTextField nameField = new JTextField(10); // Increased text field size
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1; // Increased grid width for name field
        constraints.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(nameField, constraints);

        JLabel sizeLabel = new JLabel("Size:");
        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(sizeLabel, constraints);

        JTextField sizeField = new JTextField(10);
        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.gridwidth = 1; // Increased grid width for name field
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(sizeField, constraints);

        JLabel typeLabel = new JLabel("Type:");
        constraints.gridx = 4;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(typeLabel, constraints);

        JTextField typeField = new JTextField(30);
        constraints.gridx = 5;
        constraints.gridy = 0;
        constraints.gridwidth = 5; // Increased grid width for name field
        constraints.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(typeField, constraints);


        ;


        // Table
        DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Name", "Size", "Details"}, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 10;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weightx = 1.0;
        constraints.weighty = 1.0;
        panel.add(scrollPane, constraints);

        // Buttons
        JButton addButton = new JButton("Add File");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform add file operation
            }
        });
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(addButton, constraints);

        JButton deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform delete file operation
            }
        });
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(deleteButton, constraints);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform refresh operation
            }
        });
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(refreshButton, constraints);

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }


    private void updateTable() {
        tableModel.setRowCount(0);
        ArrayList<File> files = fileManager.getFiles();
        for (File file : files) {
            String name = file.getFileName();
            String size = String.valueOf(file.getFileSize());
            String details = "";
            if (file instanceof Document) {
                Document document = (Document) file;
                details = document.getDocumentType();
            } else if (file instanceof Image) {
                Image image = (Image) file;
                details = image.getResolution();
            } else if (file instanceof Video) {
                Video video = (Video) file;
                details = video.getDuration();
            }
            tableModel.addRow(new Object[]{name, size, details});
        }
    }

    private void clearFields() {
        nameField.setText("");
        sizeField.setText("");
        typeField.setText("");
        resolutionField.setText("");
        durationField.setText("");
    }
}

public class FileManagementSystemDemo {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}
