package com.amrita.jpl.cys21062.p1;

import java.io.InputStream;

/**
 * @author Ruthwik Krishna Bandreddy
 */

public class Main {

    /**
     *
     * @param a this takes the input to reverse the number
     * @return the reversed number is given as output
     */
    public static int reverse_num(int a){
        int p = 0;
        int rem;

        while(a>0){

            rem = a%10;
            p = (p*10) + rem;
            a = a/10;
        }

        return p;
    }

    /**
     *
     * @param a  it is the first input to compare against the other numbers
     * @param b  it is the first input to compare against the other numbers
     * @param c  it is the first input to compare against the other numbers
     * @return this returns the greatest of the three
     */
    public static int large3num(int a,int b,int c){
        int large=0;
        if(a>b&& a>c){
            large = a;
        } else if (b>a&& b>c) {
            large = b;
        } else if (c>a&& b<c) {
            large = c;
        }
        return large;
    }

    /**
     *
     * @param a the input a is taken to check whether it is a perfect square or not
     */
    public static void perfect_square_check(int a) {

        for (int i = 1; i * i < a; i++) {

            if ((a % i == 0) && (a / i == i)) {

                System.out.println("true");
            }

        }}

    /**
     *
     * @param prime_test takes the input a to verify if its prime or not
     *
     */
    public static void prime_test ( int a){
        if (a % 2 != 0 && a % 3 != 0 && a % 5 != 0 && a % 7 != 0 && a % 11 != 0) {
            System.out.println("the number is prime");

        } else {
            System.out.println("The number is not prime");
        }
    }


    /**
     *
     * @param args this is the main function where all the functions are executed
     */

    public static void main(String[] args) {
        System.out.println(reverse_num(396));
        System.out.println(large3num(3,5,7));

        System.out.println( "for refrence 1 is for reverse num .2 is for large3num 3 is for perfect square 4 is for prime");
        System.out.println("please change the n in the code to change the choice value");
        int n=1;
        int t=625;


        if (n==1){
            System.out.println(reverse_num(t));
        } else if (n==2) {
            System.out.println(large3num(3,5,6));

        } else if (n==3) {
            perfect_square_check(t);
        } else if (n==4) {
            prime_test(t);
        }


    }

}

