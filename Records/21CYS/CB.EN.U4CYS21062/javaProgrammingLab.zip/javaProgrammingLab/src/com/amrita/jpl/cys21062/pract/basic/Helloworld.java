package com.amrita.jpl.cys21062.pract.basic;

public class Helloworld {
    public static void main(String[] args) {
        System.out.println("Hello,World");
    }
}
